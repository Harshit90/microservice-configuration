package com.harshit.Restaurant.App.model;



public enum USER_ROLE {



    ROLE_CUSTOMER,

    ROLE_RESTAURANT_OWNER,

    ROLE_ADMIN

}
