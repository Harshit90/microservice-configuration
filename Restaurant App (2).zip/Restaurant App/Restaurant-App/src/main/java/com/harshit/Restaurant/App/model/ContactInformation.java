package com.harshit.Restaurant.App.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


//@Data
@Getter
@Setter
public class ContactInformation {

    private String email;
    private String mobile;
    private String twitter;
    private  String instagram;

}
