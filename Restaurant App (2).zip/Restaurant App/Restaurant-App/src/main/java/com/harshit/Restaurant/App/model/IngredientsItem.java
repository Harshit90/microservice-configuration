package com.harshit.Restaurant.App.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;


@Entity
@Getter
@Setter //@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "ingredientsItem")
public class IngredientsItem {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    private String name;

    @ManyToOne
    private IngredientCategory category;

    @JsonIgnore
    @ManyToOne
    private  Restaurant restaurant;

    private boolean inStoke=true;

}
