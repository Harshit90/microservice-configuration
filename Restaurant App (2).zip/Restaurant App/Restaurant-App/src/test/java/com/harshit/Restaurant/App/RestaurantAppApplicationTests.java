package com.harshit.Restaurant.App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
